import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from 'react-native';
import { MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const categories = [
  { id: 1, name: 'Food', icon: 'food', color: '#FF6B6B' },
  { id: 2, name: 'Transport', icon: 'car', color: '#4ECDC4' },
  { id: 3, name: 'Shopping', icon: 'shopping', color: '#45B7D1' },
  { id: 4, name: 'Bills', icon: 'file-document', color: '#96CEB4' },
  { id: 5, name: 'Other', icon: 'dots-horizontal', color: '#FFEEAD' },
];

export default function ExpenseTracker() {
  const [amount, setAmount] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [isPremium, setIsPremium] = useState(false);

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  
  const addExpense = useCallback(() => {
    if (!amount || !selectedCategory) return;
    
    const newExpense = {
      id: Date.now(),
      amount: parseFloat(amount),
      category: selectedCategory,
      date: new Date(),
    };
    
    setExpenses(prev => [newExpense, ...prev]);
    setAmount('');
    setSelectedCategory(null);
  }, [amount, selectedCategory]);

  const getCategoryExpenses = (categoryId) => {
    return expenses
      .filter(exp => exp.category.id === categoryId)
      .reduce((sum, exp) => sum + exp.amount, 0);
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header with Total */}
      <LinearGradient
        colors={['#6C63FF', '#3B3780']}
        style={styles.header}>
        <Text style={styles.headerTitle}>Expense Tracker</Text>
        <Text style={styles.totalAmount}>${totalExpenses.toFixed(2)}</Text>
        <Text style={styles.monthText}>Total This Month</Text>
      </LinearGradient>

      {/* Quick Add Expense */}
      <View style={styles.addExpenseContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter amount"
          keyboardType="numeric"
          value={amount}
          onChangeText={setAmount}
        />
        <View style={styles.categoryList}>
          {categories.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton,
                selectedCategory?.id === category.id && styles.selectedCategory,
                { backgroundColor: category.color + '20' },
              ]}
              onPress={() => setSelectedCategory(category)}>
              <MaterialCommunityIcons
                name={category.icon}
                size={24}
                color={category.color}
              />
              <Text style={styles.categoryText}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={styles.addButton} onPress={addExpense}>
          <Text style={styles.addButtonText}>Add Expense</Text>
        </TouchableOpacity>
      </View>

      {/* Spending Overview */}
      <View style={styles.overviewContainer}>
        <Text style={styles.sectionTitle}>Spending Overview</Text>
        {categories.map(category => {
          const categoryTotal = getCategoryExpenses(category.id);
          const percentage = totalExpenses ? (categoryTotal / totalExpenses) * 100 : 0;
          
          return (
            <View key={category.id} style={styles.categoryRow}>
              <View style={styles.categoryInfo}>
                <MaterialCommunityIcons
                  name={category.icon}
                  size={24}
                  color={category.color}
                />
                <Text style={styles.categoryName}>{category.name}</Text>
              </View>
              <View style={styles.progressContainer}>
                <View
                  style={[
                    styles.progressBar,
                    {
                      width: `${percentage}%`,
                      backgroundColor: category.color,
                    },
                  ]}
                />
              </View>
              <Text style={styles.categoryAmount}>${categoryTotal.toFixed(2)}</Text>
            </View>
          );
        })}
      </View>

      {/* Premium Feature Teaser */}
      {!isPremium && (
        <TouchableOpacity
          style={styles.premiumBanner}
          onPress={() => setIsPremium(true)}>
          <MaterialIcons name="star" size={24} color="#FFD700" />
          <View style={styles.premiumTextContainer}>
            <Text style={styles.premiumTitle}>Upgrade to Premium</Text>
            <Text style={styles.premiumDesc}>
              Get detailed analytics, export reports, and more!
            </Text>
          </View>
          <MaterialIcons name="chevron-right" size={24} color="#666" />
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  totalAmount: {
    color: '#fff',
    fontSize: 36,
    fontWeight: 'bold',
  },
  monthText: {
    color: '#fff',
    opacity: 0.8,
  },
  addExpenseContainer: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  categoryList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: 8,
    gap: 4,
  },
  selectedCategory: {
    borderWidth: 2,
    borderColor: '#6C63FF',
  },
  categoryText: {
    fontSize: 14,
    color: '#333',
  },
  addButton: {
    backgroundColor: '#6C63FF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  overviewContainer: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  categoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  categoryInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 100,
    gap: 8,
  },
  categoryName: {
    fontSize: 14,
    color: '#333',
  },
  progressContainer: {
    flex: 1,
    height: 8,
    backgroundColor: '#f0f0f0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 4,
  },
  categoryAmount: {
    width: 80,
    textAlign: 'right',
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  premiumBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    margin: 16,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  premiumTextContainer: {
    flex: 1,
    marginLeft: 12,
  },
  premiumTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  premiumDesc: {
    fontSize: 12,
    color: '#666',
  },
});